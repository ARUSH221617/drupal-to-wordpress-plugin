jQuery(document).ready(function ($) {
  // Define a recursive function to send the AJAX requests
  function send_ajax_request(index, endpage) {
    // Check if we have reached the end of the pages
    if (index > endpage) {
      $("#arush-button-ajax-to-get-data-from-api").show(500);
      $("#arush-button-ajax-to-get-data-from-api").html("کلیک کن");
      return;
    }

    // Send an AJAX request to the server
    $.ajax({
      url: ajaxurl, // WordPress AJAX endpoint
      type: "POST",
      dataType: "json",
      data: {
        action: "get_api_data", // AJAX action to call the get_api_data function
        page: index
      },
      beforeSend: function (xhr) {
        $("#arush-button-ajax-to-get-data-from-api").html("loading...");
        $("#arush-button-ajax-to-get-data-from-api").hide(500);
      },
      success: function (response) {
        if (response.success) {
          // Handle successful API response
          // $("#alert_arush")
          if (!$("#alert_arush").hasClass("alert")) {
            $("#alert_arush").addClass("alert");
          }
          if (!$("#alert_arush").hasClass("alert-success")) {
            $("#alert_arush").addClass("alert-success");
          }
          if (!$("#alert_arush").hasClass("alert-danger")) {
            $("#alert_arush").removeClass("alert-danger");
          }
          $("#alert_arush").html(
            "عملیات با موفقیت به پایان رسید. شماره صفحه:" + index
          );
          console.log(response.data); // Use the retrieved data as needed
        } else {
          // Handle API error
          if (!$("#alert_arush").hasClass("alert")) {
            $("#alert_arush").addClass("alert");
          }
          if ($("#alert_arush").hasClass("alert-danger")) {
            $("#alert_arush").removeClass("alert-danger");
          }
          if (!$("#alert_arush").hasClass("alert-success")) {
            $("#alert_arush").removeClass("alert-success");
          }
          $("#alert_arush").html(
            "عملیات با شکست مواجه شد. شماره صفحه:" + index
          );
          $("#arush-button-ajax-to-get-data-from-api").show(500);
          var errorMessage = response.data;
          console.log(errorMessage);
        }

        // Call the send_ajax_request function again with the next index
        send_ajax_request(index + 1, endpage);
      },
      error: function (jqXHR, textStatus, errorThrown) {
        // Handle AJAX error
        if (!$("#alert_arush").hasClass("alert")) {
          $("#alert_arush").addClass("alert");
        }
        if (!$("#alert_arush").hasClass("alert-danger")) {
          $("#alert_arush").addClass("alert-danger");
        }
        if (!$("#alert_arush").hasClass("alert-success")) {
          $("#alert_arush").removeClass("alert-success");
        }
        $("#alert_arush").html("عملیات دچار مشکل شد. شماره صفحه:" + index);
        console.log("AJAX error: " + textStatus + " - " + errorThrown);

        // Call the send_ajax_request function again with the next index
        send_ajax_request(index + 1, endpage);
      }
    });
  }

  // When the button is clicked
  $("#arush-button-ajax-to-get-data-from-api").click(function () {
    let startpage = 0;
    let endpage = 6626;
    // if ($("#arush-start-page-script").val() >= 0) {
    //   startpage = $("#arush-start-page-script").val();
    // }
    // if ($("#arush-end-page-script").val() >= 0) {
    //   endpage = $("#arush-end-page-script").val();
    // }

    // Call the send_ajax_request function with the first index
    send_ajax_request(startpage, endpage);
  });
});
