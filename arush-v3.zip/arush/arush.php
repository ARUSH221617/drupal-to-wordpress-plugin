<?php
/*
Plugin Name: ARUSH
Plugin URI: https://www.arush.ir/
Description: Drupal to Wordpress
Version: 3.0
Author: Amirreza Yoneszadeh
Author URI: https://www.arush.ir/
*/
function ar_plugin_url()
{
    return plugin_dir_url(__FILE__);
}
function ar_plugin_version()
{
    return '3.0';
}

require "inc/ACF.php";
require "inc/Script.php";
require "inc/Admin.php";
require "inc/AutoLoader.php";

new \ARUSH\AutoLoader();