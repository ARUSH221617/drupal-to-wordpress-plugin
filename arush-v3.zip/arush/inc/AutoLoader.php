<?php
namespace ARUSH;

class AutoLoader
{
    public function __construct()
    {
        // init
        // $script = new Script();
        // $script->_enable_();
        $admin = new Admin();
        $admin->__construct();
        $admin->_enable_();
        // $acf = new ACF();
        // $elementor = new Element_ARUSH_Widget();
    }
}