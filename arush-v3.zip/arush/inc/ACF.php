<?php
namespace ARUSH;

class ACF
{
    public function __construct()
    {
        add_action('acf/init', [$this, 'add_gallery_field_to_acf']);
    }
    public function add_gallery_field_to_acf()
    {
        if (function_exists('acf_add_local_field_group')) {
            acf_add_local_field_group(
                array(
                    'key' => 'group_5f8b8e7a6e9c4',
                    'title' => 'گالری عکس',
                    'fields' => array(
                        array(
                            'key' => 'field_5f8b8e8b6e9c4',
                            'label' => 'عکس ها',
                            'name' => 'jahat_photo',
                            'type' => 'gallery',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                        ),
                    ),
                    'location' => array(
                        array(
                            array(
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => 'post',
                                // نوع پست مورد نظر را در اینجا قرار دهید
                            ),
                        ),
                    ),
                    'menu_order' => 0,
                    'position' => 'normal',
                    'style' => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'hide_on_screen' => '',
                    'active' => true,
                    'description' => '',
                )
            );
            acf_add_local_field_group(
                array(
                    'key' => 'group_5f8b8e7a6e9c6',
                    'title' => 'گالری ویدئو',
                    'fields' => array(
                        array(
                            'key' => 'field_5f8b8e8b6e9c6',
                            'label' => 'ویدئو ها',
                            'name' => 'jahat_video',
                            'type' => 'gallery',
                            'instructions' => '',
                            'required' => 0,
                            'conditional_logic' => 0,
                            'wrapper' => array(
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                        ),
                    ),
                    'location' => array(
                        array(
                            array(
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => 'post',
                                // نوع پست مورد نظر را در اینجا قرار دهید
                            ),
                        ),
                    ),
                    'menu_order' => 0,
                    'position' => 'normal',
                    'style' => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'hide_on_screen' => '',
                    'active' => true,
                    'description' => '',
                )
            );
        }
    }
}