<?php
namespace ARUSH;

class Admin extends Script
{
    public function __construct()
    {
        parent::__construct();
        add_action('admin_menu', [$this, 'add_admin_page']);
    }

    // Function to display the admin page
    public function admin_page_res()
    {
        ?>
        <style>
            #arush-button-ajax-to-get-data-from-api {
                display: inline-block;
                padding: 12px 24px;
                background-color: #2196F3;
                color: #fff;
                font-size: 16px;
                font-weight: bold;
                text-align: center;
                text-decoration: none;
                text-transform: uppercase;
                border-radius: 4px;
                overflow: hidden;
                position: relative;
                transition: background-color 0.3s ease;
            }

            #arush-button-ajax-to-get-data-from-api:before {
                content: "";
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 0%;
                height: 100%;
                background-color: rgba(255, 255, 255, 0.2);
                transition: width 0.3s ease;
            }

            #arush-button-ajax-to-get-data-from-api:hover:before {
                width: 100%;
            }

            #arush-button-ajax-to-get-data-from-api:hover {
                background-color: #1976D2;
            }

            #arush-end-page-script,
            #arush-start-page-script {
                display: inline-block;
                padding: 10px;
                border: 2px solid #2196F3;
                border-radius: 4px;
                font-size: 16px;
                transition: border-color 0.3s ease;
            }

            #arush-end-page-script:focus,
            #arush-start-page-script:focus {
                outline: none;
                border-color: #1976D2;
            }

            .input-container {
                position: relative;
                margin-bottom: 20px;
            }

            .input-container input {
                width: 100%;
                padding: 10px;
                border: 2px solid #2196F3;
                border-radius: 4px;
                font-size: 16px;
                transition: border-color 0.3s ease;
            }

            .input-container input:focus {
                outline: none;
                border-color: #1976D2;
            }

            .input-container label {
                position: absolute;
                top: 16px;
                right: 10px;
                color: #252525;
                font-size: 16px;
                pointer-events: none;
                transition: top 0.3s, font-size 0.3s;
                background: #f0f0f1;
            }

            .input-container input:focus~label,
            .input-container input:valid~label {
                top: -16px;
                font-size: 16px;
            }

            .alert {
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 16px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 4px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
                margin-bottom: 20px;
            }

            .alert-success {
                background-color: #43A047;
                color: #fff;
            }

            .alert-danger {
                background-color: #E53935;
                color: #fff;
            }
        </style>
        <div class="wrap">
            <p>سلام به انتقال دهنده خوش آمدی!</p>
            <div>
                <p>برای انتقال مطالب ها</p>
                <div id="alert_arush">
                </div>
                <!-- <div class="input-container">
                    <input type="number" id="arush-start-page-script" value="0">
                    <label for="#arush-start-page-script">شمارع صفحه در شروع واکشی</label>
                </div>
                <div class="input-container">
                    <input type="number" id="arush-end-page-script" value="6625">
                    <label for="#arush-end-page-script">شمارع صفحه در پایان واکشی</label>
                </div> -->
                <button type="button" id="arush-button-ajax-to-get-data-from-api">کلیک کن</button>
            </div>
        </div>
        <?php
    }

    // Function to add the admin menu item
    function add_admin_page()
    {
        $menu = add_menu_page(
            'ARUSH',
            // Page title
            'ARUSH',
            // Menu title
            'manage_options',
            // Capability required to access the menu item
            'arush',
            // Menu slug
            [$this, 'admin_page_res'],
            // Callback function to display the page content
            'dashicons-admin-generic',
            // Icon
            99 // Position
        );
        add_action('admin_print_scripts-' . $menu, [$this, 'enqueue_scripts']);
    }
}