<?php
namespace ARUSH;

use DOMDocument;
use DOMXPath;

class Script
{
    public function __construct()
    {
    }
    // adds AJAX action hooks for the "wp_ajax_get_api_data" and "wp_ajax_nopriv_get_api_data" actions, which are used to retrieve API data.
    public function _enable_()
    {
        // AJAX endpoint for retrieving API data
        add_action('wp_ajax_get_api_data', [$this, 'get_api_data']);
        add_action('wp_ajax_nopriv_get_api_data', [$this, 'get_api_data']);
    }
    // sets the PHP configuration options to display errors and logs a specific error if provided.
    public function error_show_in_log($log = "")
    {
        // ini_set('display_errors', 1);
        // ini_set('display_startup_errors', 1);
        // error_reporting(E_ALL);
        if (!empty($log)) {
            error_log($log);
        }
        return true;
    }

    // enqueues a JavaScript file with a jQuery dependency using the WordPress wp_enqueue_script() function.
    public function enqueue_scripts()
    {
        wp_enqueue_script('api-button-click-script', ar_plugin_url() . '/assets/js/script.js', array('jquery'), ar_plugin_version(), true);
    }
    // takes an image URL and a post ID, downloads the image, and sets it as the featured image for the specified post.
    public function Generate_Featured_Image($image_url, $post_id)
    {
        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($image_url);
        $filename = basename($image_url);
        if (wp_mkdir_p($upload_dir['path']))
            $file = $upload_dir['path'] . '/' . $filename;
        else
            $file = $upload_dir['basedir'] . '/' . $filename;
        file_put_contents($file, $image_data);

        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        $res1 = wp_update_attachment_metadata($attach_id, $attach_data);
        $res2 = set_post_thumbnail($post_id, $attach_id);
    }
    public function filter_video_and_image_and_drupal_media_url($id, $content)
    {
        if ($content != "") {
            $mediaArray = [];
            $post = file_get_contents("https://jahatpress.ir/fa/news/" . $id);

            $dom = new DOMDocument('1.0', 'UTF-8');
            @$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'));

            $sdom = new DOMDocument('1.0', 'UTF-8');
            @$sdom->loadHTML(mb_convert_encoding($post, 'HTML-ENTITIES', 'UTF-8'));

            $DOMxpath = new DOMXPath($dom);
            $drupalMediaTags = $DOMxpath->evaluate('//*[self::img or self::drupal-media]');
            $drupalMediaArray = iterator_to_array($drupalMediaTags);

            $xpath = new DOMXPath($sdom);
            $mediaTags = $xpath->evaluate('/html/body/main//div[@class="cBody"]//*[self::img or self::video]');

            if ($mediaTags->length > 0) {
                foreach ($mediaTags as $mediaTag) {
                    if ($mediaTag->tagName == "video") {
                        $sourceTag = $mediaTag->getElementsByTagName('source')->item(0);
                        $oldSrc = $sourceTag->getAttribute("src");
                        $newSrc = strstr(urldecode($sourceTag->getAttribute("src")), 'https://pbs.twimg.com') ? $oldSrc : (!strstr(urldecode($sourceTag->getAttribute("src")), 'http') ? 'https://jahatpress.ir' . $oldSrc : $oldSrc);
                        $sourceTag->setAttribute("src", $newSrc);
                        // Download the video
                        if (!strstr(urldecode($sourceTag->getAttribute("src")), 'https://pbs.twimg.com')) {
                            $mediaContent = file_get_contents($newSrc);
                            if ($mediaTag->hasAttribute("data-entity-uuid")) {
                                $filetype = explode(".", basename($newSrc));
                                $filename = $mediaTag->getAttribute("data-entity-uuid") . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                            } else {
                                $filetype = explode(".", basename($newSrc));
                                $filename = md5(basename($newSrc)) . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                            }
                            $uploadDir = wp_upload_dir();
                            $filePath = $uploadDir['path'] . '/' . $filename;
                            file_put_contents($filePath, $mediaContent);
                            // Set the new source dynamically
                            $sourceTag->setAttribute("src", $uploadDir['url'] . '/' . $filename);
                        }
                    } else if ($mediaTag->tagName == "img") {
                        $oldSrc = $mediaTag->getAttribute("src") != "" ? $mediaTag->getAttribute("src") : $mediaTag->getAttribute("data-src");
                        $newSrc = strstr(urldecode($mediaTag->getAttribute("src")), 'https://pbs.twimg.com') ? $oldSrc : (!strstr(urldecode($mediaTag->getAttribute("src")), 'http') ? 'https://jahatpress.ir' . $oldSrc : $oldSrc);
                        $mediaTag->setAttribute("src", $newSrc);
                        // Download the image
                        if (!strstr(urldecode($mediaTag->getAttribute("src")), 'https://pbs.twimg.com')) {
                            $image_content = file_get_contents($newSrc);
                            $upload_dir = wp_upload_dir();
                            if ($mediaTag->hasAttribute("data-entity-uuid")) {
                                $filetype = explode(".", basename($newSrc));
                                $filename = $mediaTag->getAttribute("data-entity-uuid") . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                            } else {
                                $filetype = explode(".", basename($newSrc));
                                $filename = md5(basename($newSrc)) . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                            }
                            $file_path = $upload_dir['path'] . '/' . $filename;
                            file_put_contents($file_path, $image_content);

                            // Set the new source dynamically
                            $mediaTag->setAttribute("src", $upload_dir['url'] . '/' . $filename);
                        }
                    }
                }
            }

            @$mediaArray = iterator_to_array($mediaTags);

            if (count($drupalMediaArray) > 0) {
                foreach ($drupalMediaArray as $index => $drupalMediaTag) {
                    if ($mediaArray && isset($mediaArray[$index])) {
                        $mediaTag = $mediaArray[$index];
                        $tagName = $mediaTag->tagName;
                        $newTag = $dom->createElement($tagName);
                        if ($tagName == "video") {
                            $sourceTag = $mediaArray[$index]->childNodes[0];

                            $sourceTagName = $sourceTag->tagName;
                            $sourceNewTag = $dom->createElement($sourceTagName);

                            foreach ($sourceTag->attributes as $attribute) {
                                $sourceNewTag->setAttribute($attribute->name, $attribute->value);
                            }


                            if ($drupalMediaTag && $newTag) {
                                foreach ($mediaTag->attributes as $attribute) {
                                    $newTag->setAttribute($attribute->name, $attribute->value);
                                }
                                $newTag->appendChild($sourceNewTag);
                                $drupalMediaTag->parentNode->replaceChild($newTag, $drupalMediaTag);
                            }
                        } else if ($tagName == "img") {
                            if ($drupalMediaTag && $newTag) {
                                foreach ($mediaTag->attributes as $attribute) {
                                    $newTag->setAttribute($attribute->name, $attribute->value);
                                }
                                $drupalMediaTag->parentNode->replaceChild($newTag, $drupalMediaTag);
                            }
                        }
                    }
                }
            }

            $dom->formatOutput = true;
            $content = $dom->getElementsByTagName('body')->item(0);
            $contentValue = '';
            foreach ($content->childNodes as $node) {
                $contentValue .= $dom->saveHTML($node);
            }

            return $contentValue;
        }
        return $content;
    }
    public function filter_jahat_videos($videos)
    {
        $videosURL = [];
        foreach ($videos as $video) {
            $videoURL = $video->url;

            // Validate URL
            if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
                $mediaContent = @file_get_contents($videoURL);

                if ($mediaContent !== false) {
                    $filetype = explode(".", basename($videoURL));
                    $filename = md5(basename($videoURL)) . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                    $tmpDir = sys_get_temp_dir();
                    $filePath = $tmpDir . '/' . $filename;

                    // Handle file writing errors
                    if (@file_put_contents($filePath, $mediaContent) !== false) {
                        // Add file to WordPress media library
                        $file = array(
                            'name' => basename($filePath),
                            'type' => wp_check_filetype(basename($filePath), null)['type'],
                            'tmp_name' => $filePath,
                            'error' => 0,
                            'size' => filesize($filePath)
                        );
                        $upload = wp_handle_sideload($file, array('test_form' => false));

                        if ($upload && !isset($upload['error'])) {
                            // If the file was successfully uploaded, create a new post of type attachment
                            $post = array(
                                'post_title' => $file['name'],
                                'post_content' => '',
                                'post_type' => 'attachment',
                                'post_mime_type' => $file['type'],
                                'guid' => $upload['url']
                            );

                            // Insert the new post and get its ID
                            $attach_id = wp_insert_attachment($post, $upload['url']);

                            if (!is_wp_error($attach_id)) {
                                // Generate attachment metadata
                                require_once ABSPATH . 'wp-admin/includes/image.php';
                                $attach_data = wp_generate_attachment_metadata($attach_id, $filePath);
                                wp_update_attachment_metadata($attach_id, $attach_data);

                                $videosURL[] = $attach_id;
                            }
                        } else {
                            // Error while uploading the file
                            $this->error_show_in_log('Error while uploading the file: ' . $upload['error']);
                        }
                    } else {
                        // Error while writing the file
                        $this->error_show_in_log('Error while writing the file');
                    }
                } else {
                    // Error while fetching media content
                    $this->error_show_in_log('Error while fetching media content from URL');
                }
            } else {
                // Invalid URL
                $this->error_show_in_log('Invalid video URL: ' . $videoURL);
            }
        }

        return $videosURL;
    }

    public function filter_jahat_images($images)
    {
        $imagesURL = [];
        foreach ($images as $image) {
            $imageURL = $image->url;

            // Validate URL
            if (filter_var($imageURL, FILTER_VALIDATE_URL)) {
                $mediaContent = file_get_contents($imageURL);

                if ($mediaContent !== false) {
                    $filetype = explode(".", basename($imageURL));
                    $filename = md5(basename($imageURL)) . (!strstr(end($filetype), ".") ? "." . end($filetype) : end($filetype));
                    $tmpDir = sys_get_temp_dir();
                    $filePath = $tmpDir . '/' . $filename;

                    // Handle file writing errors
                    if (file_put_contents($filePath, $mediaContent) !== false) {
                        // Add file to WordPress media library
                        $file = array(
                            'name' => basename($filePath),
                            'type' => wp_check_filetype(basename($filePath), null)['type'],
                            'tmp_name' => $filePath,
                            'error' => 0,
                            'size' => filesize($filePath)
                        );
                        $upload = wp_handle_sideload($file, array('test_form' => false));

                        if ($upload && !isset($upload['error'])) {
                            // If the file was successfully uploaded, create a new post of type attachment
                            $post = array(
                                'post_title' => $file['name'],
                                'post_content' => '',
                                'post_type' => 'attachment',
                                'post_mime_type' => $file['type'],
                                'guid' => $upload['url']
                            );

                            // Insert the new post and get its ID
                            $attach_id = wp_insert_attachment($post, $upload['url']);

                            if (!is_wp_error($attach_id)) {
                                // Generate attachment metadata
                                require_once ABSPATH . 'wp-admin/includes/image.php';
                                $attach_data = wp_generate_attachment_metadata($attach_id, $filePath);
                                wp_update_attachment_metadata($attach_id, $attach_data);

                                $imagesURL[] = $attach_id;
                            }
                        } else {
                            // Error while uploading the file
                            $this->error_show_in_log('Error while uploading the file: ' . $upload['error']);
                        }
                    } else {
                        // Error while writing the file
                        $this->error_show_in_log('Error while writing the file');
                    }
                } else {
                    // Error while fetching media content
                    $this->error_show_in_log('Error while fetching media content from URL');
                }
            } else {
                // Invalid URL
                $this->error_show_in_log('Invalid image URL: ' . $imageURL);
            }
        }

        return $imagesURL;
    }
    // Function to get API data
    public function get_api_data()
    {
        // Get page from POST request
        $page = $_POST['page'];

        // Set API URL
        $api_url = 'https://jahatpress.ir/fa/ape-api/047fj098750/export/nodes/page/' . $page;

        // Make a remote request to the API URL
        $response = wp_remote_get($api_url);

        // Check if there is an error in the response
        if (is_wp_error($response)) {
            // Get the error message
            $error_message = $response->get_error_message();

            // Send JSON error response
            wp_send_json_error($error_message);
        } else {
            // Decode the response body
            $response = (json_decode($response["body"])->data);

            // Loop through the response data
            foreach ($response as $post_id) {
                // Set API URL for post info
                $api_url_post = 'https://jahatpress.ir/fa/ape-api/047fj098750/export/node-info/' . $post_id;

                // Make a remote request to the API URL
                $response_post = wp_remote_get($api_url_post);

                // Check if there is an error in the response
                if (is_wp_error($response_post)) {
                    // Get the error message
                    $error_message = $response_post->get_error_message();

                    // Send JSON error response
                    wp_send_json_error($error_message);
                } else {
                    // Decode the response body
                    $response_post_data = json_decode($response_post["body"]);

                    // Check if the response data is valid
                    if ($response_post_data && isset($response_post_data->data)) {
                        // Get the response data
                        $response_post_data = $response_post_data->data;

                        // Initialize array for post categories name
                        $post_cats_name = [];

                        // Loop through the categories
                        foreach ($response_post_data->field_category as $cats) {
                            // Check if the category name is not empty
                            if ($cats->name != "" && !empty($cats->name)) {
                                // Add the category name to the array
                                $cats_name[] = $cats->name;

                                // Create the category and add it to the array
                                $post_cats_name[] = wp_create_category(__($cats->name));
                            }
                        }

                        // Initialize array for post tags name
                        $post_tags_name = [];

                        // Loop through the tags
                        foreach ($response_post_data->field_tags as $tags) {
                            // Check if the tag name is not empty
                            if ($tags->name != "" && !empty($tags->name)) {
                                // Add the tag name to the array
                                $tags_name[] = $tags->name;

                                // Add the tag to the array
                                $post_tags_name[] = __($tags->name);
                            }
                        }

                        // Set arguments for the post
                        $args = [
                            "post_title" => wp_strip_all_tags($response_post_data->title),
                            "post_author" => get_current_user_id(),
                            "post_excerpt" => wp_strip_all_tags($response_post_data->summary),
                            "post_content" => $this->filter_video_and_image_and_drupal_media_url($response_post_data->id, $response_post_data->body),
                            "post_status" => $response_post_data->pub_state == 1 ? "publish" : "draft",
                            "post_type" => "post",
                            "post_category" => $post_cats_name,
                            "tags_input" => $post_tags_name,
                            "post_date" => date("Y-m-d H:i:s", strtotime($response_post_data->field_publish_date)),
                            "meta_input" => [
                                "jahat_surtitle" => $response_post_data->field_surtitle,
                                "jahat_video" => $this->filter_jahat_videos($response_post_data->field_attach_video),
                                "jahat_photo" => $this->filter_jahat_images($response_post_data->field_attach_pics)
                            ]
                        ];

                        // Remove filters
                        kses_remove_filters();

                        // Insert the post
                        $id = wp_insert_post($args);

                        // Re-add filters
                        kses_init_filters();

                        // Check if there is an error in the response
                        if (!is_wp_error($id)) {
                            // Generate featured image
                            $this->Generate_Featured_Image($response_post_data->field_thumb[0]->url, $id);
                        } else {
                            // Get the error message
                            $error_message = $id->get_error_message();

                            // Send JSON error response
                            wp_send_json_error($error_message);

                            // Show error in log
                            $this->error_show_in_log($page . " ): " . $post_id . " -> wp error");
                        }
                    } else {
                        // Show error in log
                        $this->error_show_in_log($page . " ): " . $post_id . " -> target server error");
                    }
                }
            }

            // Send JSON success response
            wp_send_json_success(json_encode(["data" => $page]));
        }
    }
}