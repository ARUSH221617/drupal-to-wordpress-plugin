<?php
namespace ARUSH;

use DOMDocument;
use DOMXPath;

class Script
{
    public function __construct()
    {
    }
    // adds AJAX action hooks for the "wp_ajax_get_api_data" and "wp_ajax_nopriv_get_api_data" actions, which are used to retrieve API data.
    public function _enable_()
    {
        // AJAX endpoint for retrieving API data
        add_action('wp_ajax_get_api_data', [$this, 'get_api_data']);
        add_action('wp_ajax_nopriv_get_api_data', [$this, 'get_api_data']);
    }
    // sets the PHP configuration options to display errors and logs a specific error if provided.
    public function error_show_in_log($log = "")
    {
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        if (!empty($log)) {
            error_log($log);
        }
        return true;
    }

    // enqueues a JavaScript file with a jQuery dependency using the WordPress wp_enqueue_script() function.
    public function enqueue_scripts()
    {
        wp_enqueue_script('api-button-click-script', ar_plugin_url() . '/assets/js/script.js', array('jquery'), ar_plugin_version(), true);
    }
    // takes an image URL and a post ID, downloads the image, and sets it as the featured image for the specified post.
    public function Generate_Featured_Image($image_url, $post_id)
    {
        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($image_url);
        $filename = basename($image_url);
        if (wp_mkdir_p($upload_dir['path']))
            $file = $upload_dir['path'] . '/' . $filename;
        else
            $file = $upload_dir['basedir'] . '/' . $filename;
        file_put_contents($file, $image_data);

        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        $res1 = wp_update_attachment_metadata($attach_id, $attach_data);
        $res2 = set_post_thumbnail($post_id, $attach_id);
    }
    public function filter_video_and_image_and_drupal_media_url($id, $content)
    {
        if ($content != "") {
            $mediaArray = [];
            $post = file_get_contents("https://jahatpress.ir/fa/news/" . $id);

            $dom = new DOMDocument('1.0', 'UTF-8');
            @$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'));

            $sdom = new DOMDocument('1.0', 'UTF-8');
            @$sdom->loadHTML(mb_convert_encoding($post, 'HTML-ENTITIES', 'UTF-8'));

            $DOMxpath = new DOMXPath($dom);
            $drupalMediaTags = $DOMxpath->evaluate('//*[self::img or self::drupal-media]');
            $drupalMediaArray = iterator_to_array($drupalMediaTags);

            $xpath = new DOMXPath($sdom);
            $mediaTags = $xpath->evaluate('/html/body/main//div[@class="cBody"]//*[self::img or self::video]');

            if ($mediaTags->length > 0) {
                foreach ($mediaTags as $mediaTag) {
                    if ($mediaTag->tagName == "video") {
                        $sourceTag = $mediaTag->getElementsByTagName('source')->item(0);
                        $oldSrc = rawurldecode($sourceTag->getAttribute("src"));
                        $newSrc = !strstr(urldecode($sourceTag->getAttribute("src")), 'http') ? 'https://jahatpress.ir' . $oldSrc : $oldSrc;
                        $sourceTag->setAttribute("src", $newSrc);
                        // Download the video
                        $mediaContent = file_get_contents($newSrc);
                        if ($mediaTag->hasAttribute("data-entity-uuid")) {
                            $filename = $mediaTag->getAttribute("data-entity-uuid") . filetype(basename($newSrc));
                        } else {
                            $filename = md5(basename($newSrc)) . filetype(basename($newSrc));
                        }
                        $uploadDir = wp_upload_dir();
                        $filePath = $uploadDir['path'] . '/' . $filename;
                        file_put_contents($filePath, $mediaContent);
                        // Set the new source dynamically
                        $sourceTag->setAttribute("src", $uploadDir['url'] . '/' . $filename);
                    } else if ($mediaTag->tagName == "img") {
                        $oldSrc = rawurldecode($mediaTag->getAttribute("src") != "" ? $mediaTag->getAttribute("src") : $mediaTag->getAttribute("data-src"));
                        $newSrc = !strstr(urldecode($mediaTag->getAttribute("src")), 'http') ? 'https://jahatpress.ir' . $oldSrc : $oldSrc;
                        $mediaTag->setAttribute("src", $newSrc);
                        // Download the image
                        $image_content = file_get_contents($newSrc);
                        $upload_dir = wp_upload_dir();
                        if ($mediaTag->hasAttribute("data-entity-uuid")) {
                            $filename = $mediaTag->getAttribute("data-entity-uuid") . filetype(basename($newSrc));
                        } else {
                            $filename = md5(basename($newSrc)) . filetype(basename($newSrc));
                        }
                        $file_path = $upload_dir['path'] . '/' . $filename;
                        file_put_contents($file_path, $image_content);

                        // Set the new source dynamically
                        $mediaTag->setAttribute("src", $upload_dir['url'] . '/' . $filename);
                    }
                }
            }

            @$mediaArray = iterator_to_array($mediaTags);

            if (count($drupalMediaArray) > 0) {
                foreach ($drupalMediaArray as $index => $drupalMediaTag) {
                    if ($mediaArray && isset($mediaArray[$index])) {
                        $mediaTag = $mediaArray[$index];
                        $tagName = $mediaTag->tagName;
                        $newTag = $dom->createElement($tagName);
                        if ($tagName == "video") {
                            $sourceTag = $mediaArray[$index]->childNodes[0];
                            var_dump($sourceTag);

                            $sourceTagName = $sourceTag->tagName;
                            $sourceNewTag = $dom->createElement($sourceTagName);

                            foreach ($sourceTag->attributes as $attribute) {
                                $sourceNewTag->setAttribute($attribute->name, $attribute->value);
                            }


                            if ($drupalMediaTag && $newTag) {
                                foreach ($mediaTag->attributes as $attribute) {
                                    $newTag->setAttribute($attribute->name, $attribute->value);
                                }
                                $newTag->appendChild($sourceNewTag);
                                $drupalMediaTag->parentNode->replaceChild($newTag, $drupalMediaTag);
                            }
                        } else if ($tagName == "img") {
                            if ($drupalMediaTag && $newTag) {
                                foreach ($mediaTag->attributes as $attribute) {
                                    $newTag->setAttribute($attribute->name, $attribute->value);
                                }
                                $drupalMediaTag->parentNode->replaceChild($newTag, $drupalMediaTag);
                            }
                        }
                    }
                }
            }

            $dom->formatOutput = true;
            $content = $dom->getElementsByTagName('body')->item(0);
            $contentValue = '';
            foreach ($content->childNodes as $node) {
                $contentValue .= $dom->saveHTML($node);
            }

            return $contentValue;
        }
        return $content;
    }
    // is an AJAX handler function. It retrieves API data from a specific URL, processes the response, and creates new posts in WordPress based on the retrieved data. It also calls the filter_video_and_drupal_media_url() and filter_image_url() methods to modify the content before inserting it into the posts.
    public function get_api_data()
    {
        // Extract the parameter from the AJAX request
        $page = $_POST['page'];
        // API endpoint URL
        $api_url = 'https://jahatpress.ir/fa/ape-api/047fj098750/export/nodes/page/' . $page;
        // Make the API request
        $response = wp_remote_get($api_url);
        // Check if the request was successful
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            wp_send_json_error($error_message);
        } else {
            $response = (json_decode($response["body"])->data);
            foreach ($response as $post_id) {
                // API endpoint URL
                $api_url_post = 'https://jahatpress.ir/fa/ape-api/047fj098750/export/node-info/' . $post_id;
                // Make the API request
                $response_post = wp_remote_get($api_url_post);
                // Check if the request was successful
                if (is_wp_error($response_post)) {
                    $error_message = $response_post->get_error_message();
                    wp_send_json_error($error_message);
                } else {
                    $response_post_data = json_decode($response_post["body"]);
                    if ($response_post_data && isset($response_post_data->data)) {
                        $response_post_data = $response_post_data->data;

                        // $existingPostData = [];

                        // Check if the post already exists

                        // if (!post_exists($response_post_data->title)) {
                        // Post doesn't exist or is not published, so create a new one
                        $post_cats_name = [];
                        foreach ($response_post_data->field_category as $cats) {
                            if ($cats->name != "" && !empty($cats->name)) {
                                $cats_name[] = $cats->name;
                                $post_cats_name[] = wp_create_category(__($cats->name));
                            }
                        }
                        $post_tags_name = [];
                        foreach ($response_post_data->field_tags as $tags) {
                            if ($tags->name != "" && !empty($tags->name)) {
                                $tags_name[] = $tags->name;
                                $post_tags_name[] = __($tags->name);
                            }
                        }
                        // Create a new post
                        $args = [
                            "post_title" => wp_strip_all_tags($response_post_data->title),
                            "post_author" => get_current_user_id(),
                            "post_excerpt" => wp_strip_all_tags($response_post_data->summary),
                            "post_content" => $this->filter_video_and_image_and_drupal_media_url($response_post_data->id, $response_post_data->body_convert),
                            "post_status" => $response_post_data->pub_state == 1 ? "publish" : "draft",
                            "post_type" => "post",
                            "post_category" => $post_cats_name,
                            "tags_input" => $post_tags_name,
                            "post_date" => date("Y-m-d H:i:s", strtotime($response_post_data->field_publish_date)),
                            "meta_input" => [
                                "jahat_surtitle" => $response_post_data->field_surtitle,
                                "jahat_video" => $response_post_data->field_attach_video,
                                "jahat_photo" => $response_post_data->field_attach_pics
                            ]
                        ];
                        kses_remove_filters();
                        $id = wp_insert_post($args);
                        kses_init_filters();
                        if (!is_wp_error($id)) {
                            // Generate and set the featured image
                            $this->Generate_Featured_Image($response_post_data->field_thumb[0]->url, $id);
                        } else {
                            $error_message = $id->get_error_message();
                            wp_send_json_error($error_message);
                            $this->error_show_in_log($page . " ): " . $post_id . " -> wp error");
                        }
                        // } else {
                        //     $existingPostData[] = [$response_post_data->id, $response_post_data->title];
                        // }
                    } else {
                        $this->error_show_in_log($page . " ): " . $post_id . " -> target server error");
                        // wp_send_json_error(json_encode(["data" => $page, "post" => $post_id]));
                    }
                }
            }
            wp_send_json_success(json_encode(["data" => $page]));
        }
    }
}